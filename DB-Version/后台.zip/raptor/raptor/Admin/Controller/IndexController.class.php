<?php
namespace Admin\Controller;
use Common\Controller\BaseadminController;
class IndexController extends BaseadminController {
    public function index(){
        $this->display();
    }
}

<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <title>匠迪云</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link rel="shortcut icon" href="/Public/admin/Images/favicon.ico"/>
    <link rel="stylesheet" href="/Public/admin/Css/bootstrap.css">
    <link rel="stylesheet" href="/Public/admin/Css/iframe-useopera.css">
    <link rel="stylesheet" href="/Public/admin/Css/table.css">

    <script src="/Public/admin/Js/jquery-3.1.1.min.js"></script>
    <script src="/Public/admin/Js/bootstrap.min.js"></script>
    <script src="/Public/admin/Js/bootstrap-table.js"></script>
    <script src="/Public/admin/Js/echarts.js"></script>
    <script src="/Public/admin/Js/dark.js"></script>

</head>
<body>

<!--------------滚动条----------->
<div class="scroll-container">
    <div class="scroll">
        <table class="table table-bordered" id = "table">
        </table>
    </div>
</div>
<script src="/Public/admin/Js/useroper.js"></script>
</body>
</html>
<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/Public/Css/bootstrap.css">
    <link rel="stylesheet" href="/Public/Css/caf.css">
    <link rel="stylesheet" href="/Public/Css/table.css">
    <link rel="stylesheet" href="/Public/Css/messshow.css">

</head>
<body>
<div  class="tab-content tab-content-top">
    <div class="scroll-container">
        <div class="scroll">

            <div class="tab-pane fade in active changecode" id="tabmessage">
			<?php if(!empty($content_array)){?>
                <table>
                    <?php foreach($content_array as $key => $value){?>
                        <tr style="font-size: 13px" id="<?php echo $key+1 ?>">
                            <td>
                                <?php echo $key+1 ?>
                            </td>
                            <td>
                                <?php echo '<pre id="pre">';echo $value ?>
                            </td>
                        </tr>
                    <?php }?>
                </table>
			<?php }?>
            </div>
        </div>
    </div>
</div>
<!--下面结构-->
<ul class="nav nav-tabs tabsT">   
    <li class="active"><a href="#tab2" data-toggle="tab" class="tab-titles">缺陷描述</a></li>
    <li><a href="#tab3" data-toggle="tab" class="tab-titles">修改建议</a></li>
    <li><a href="#tab4" data-toggle="tab" class="tab-titles">缺陷审计</a></li>
	<li><a href="#tab1" data-toggle="tab" class="tab-titles">跟踪路径</a></li>
</ul>
<div  class="tab-content tab-content-bottom ">
    <div class="tab-pane fade in active changedescribe scroll-right" id="tab2">
        <p class="part4-text">
            <?php echo $audit['warning_ms'];?>
        </p>
    </div>
    <div class="tab-pane fade changesuggest  scroll-right" id="tab3">
        <p class="part4-text">
            <?php echo $audit['message'] ?>
        </p>
    </div>
    <div class="tab-pane fade changeaudit  scroll-right" id="tab4">

        <form action="" class="audit-form" method="post">
            <div class="audit-relative">
                <span class="audit-title">告警等级</span>
                <div class="level-posi">
                    <input name="file" type="hidden" value="<?php echo $audit['track']['file'] ?>">
                    <input name="line" type="hidden" value="<?php echo $audit['track']['line'] ?>">
                    <input name="warning_type" type="hidden" value="<?php echo $fu_key ?>">
                    <input type="radio" name="grade" id="height" value="高" <?php if($audit['severity'] == '1'){?> checked <?php }?> >
                    <label for="height"></label>
                    <span class="grade-cla">高</span>

                    <input type="radio" name="grade" id="middle" value="中" <?php if($audit['severity'] == '2'){?> checked <?php }?>>
                    <label for="middle" style="left: 48px;"></label>
                    <span class="grade-cla">中</span>

                    <input type="radio" name="grade" id="low" value="低" <?php if($audit['severity'] == '3'){?> checked <?php }?>>
                    <label for="low" style="left: 94px;"></label>
                    <span class="grade-cla">低</span>

                    <input type="radio" name="grade" id="ign" value="忽略" <?php if($audit['severity'] == '4'){?> checked <?php }?>>
                    <label for="ign" style="left: 138px;"></label>
                    <span class="grade-cla">忽略</span>
                </div>
            </div>
            <div class="audit-relative-bott">
                <span class="audit-title">备注</span>
                <textarea class="text-area" name="describe"><?php echo $audit['describe'] ?></textarea>
            </div>
            <button type="submit" class="sub">提交</button>
        </form>
    </div>
    <div class="tab-pane fade in changepath  scroll-right" id="tab1">
        <!--推入跟踪路径   表格-->
        <table id = "tableBottom" class="table table-bordered" style="margin-top: 0">
        </table>
    </div>
</div>
<script src = "/Public/Js/jquery-3.1.1.min.js"></script>
<script src = "/Public/Js/bootstrap.min.js"></script>
<script src="/Public/Js/bootstrap-table.js"></script>
<script>
    $(function(){
        //警告行数显示
        var line_num = "<?php echo $audit['track']['line'] ?>";
        $('#'+line_num+' #pre').css('background','#3a80a7');
        var top = $('#'+line_num).offset().top;
        $('.scroll').scrollTop(top-100);
    });

    $('#tableBottom').bootstrapTable({
        columns: [
            {
                field: 'file',
                title: '文件名',
                align:'center',
                valign:'middle'

            }, {
                field: 'line',
                title: '行号',
                align:'center',
                valign:'middle'
            },{
                field: 'code',
                title: '代码段',
                align:'center',
                valign:'middle'
            }],
        data:[<?php echo $data_json ?>]
    });
</script>
</body>
</html>
<?php
namespace Home\Controller;
use Common\Controller\BaseController;
class AnalysisController extends BaseController {
    public function codeAnalysis(){
        $this->display();
    }
    //代码分析  --总览视图
    public function issues(){
        $login = D('Analysis');
        $isLogin = $login->isLogin();

        if($isLogin){
            if($_GET['info_id']){
                $info_id = $_GET['info_id'];
            }else{
                $info_id = $login->new_detection();//获取最近检测的upload_id
            }

            $this->assign('info_id',$info_id);
            $this->display('issues');
        }else{
            $this->redirect('Home/Index/index');//如果未登录。跳转到登录页
        }

    }


    //代码分析  --总览视图
    public function issues2(){
    	$login = D('Analysis');
    	$isLogin = $login->isLogin();

        $info_id = $_GET['info_id'];

        $summary_id = $login->getSummaryId($info_id);

        $file_class = $login->file_class($summary_id);             //文件分类视图 
        $degree_clas = $login->degree_class($summary_id);         //程度分类视图

        foreach($degree_clas as $k => $v){
            if($k == '1'){
                $degree_class['高'] = $v;
            }else if($k == '2'){
                $degree_class['中'] = $v;
            }else if($k == '3'){
                $degree_class['低'] = $v;
            }else if($k == '4'){
                $degree_class['忽略'] = $v;
            }
        }
        $risk_class = $login->risk_class($summary_id);             //风险分类视图数据

        $result = [
            'data2' => $file_class,
            'data4' => $degree_class,
            'data6' => $risk_class,
        ];
        echo json_encode($result);

    }

    //代码分析  ---分览视图
    public function issues_bro(){
        //{ ["php"]=> int(7466) ["js"]=> int(4) }   头部展示的语言格式
        $login = D('Analysis');

        $isLogin = $login->isLogin();
        if($isLogin){
            if($_GET['info_id']){
                $info_id = $_GET['info_id'];
            }else{
                $info_id = $login->new_detection();//获取最近检测的upload_id
            }

            $summary_id = $login->getSummaryId($info_id);

            $file_class = $login->file_class($summary_id);

            $this->assign('file_class',$file_class);
            $this->assign('info_id',$info_id);
            $this->display('issues_bro');
        }else{
            $this->redirect('Home/Index/index');//如果未登录。跳转到登录页
        }

    }

    //代码分析  ---分览视图
    public function issues_bro2(){
        $login = D('Analysis');

        $info_id = $_GET['info_id'];
        $code = $_GET['codetype'];
        $level = !empty($_GET['level']) ? $_GET['level'] : '';
        if(!$code){
            $code = '';
        }

        $level = $_GET['level'];

        if($level == '高'){
            $level = '1';
        }else if($level == '中'){
            $level = '2';
        }else if($level == '低'){
            $level = '3';
        }else if($level == '忽略'){
            $level = '4';
        }else{
            $level = '';
        }

        $summary_id = $login->getSummaryId($info_id);//获取summary_id

        $file_class = $login->file_class($summary_id);//获取文件分类

        $grade = $login->degree_class($summary_id,$code);//获取程度分类

        foreach($grade as $k => $v){
            if($k == '1'){
                $gradeType['高'] = $v;
            }else if($k == '2'){
                $gradeType['中'] = $v;
            }else if($k == '3'){
                $gradeType['低'] = $v;
            }else if($k == '4'){
                $gradeType['忽略'] = $v;
            }
        }
        $riskType = $login->risk_class($summary_id,$code,$level);//获取风险分类

        $risk = $_GET['risk'];

        $risk_detail = $login->branch_detail_class($summary_id,$code,$level,$risk);//风险分类信息表格详情

        $result = [
            'owner_grade' => $gradeType,
            'owner_risk' => $riskType,
            'owner_data' => $risk_detail
        ];
        // var_dump($result);
        echo json_encode($result);
    }



    //代码分析  ---在线审计
    public function online(){
        $login = D('Analysis');
        $isLogin = $login->isLogin();

        if($isLogin){
            if($_GET['info_id']){
                $info_id = $_GET['info_id'];
            }else{
                $info_id = $login->new_detection();//获取最近检测的upload_id
            }
            $summary_id = $login->getSummaryId($info_id);
            $degree_clas = $login->degree_class($summary_id);         //程度分类视图

            if(empty($_GET['data_type'])){  //左侧导航栏=======
                $level = '';             
            }else{
                $level = $_GET['data_type'];
            }

            $data['warnings'] = $login->branch_detail_class($summary_id,'',$level);

            $chart_vulntype_metrics = array(); //风险分类
            $chart_severity_metrics = Array();//程度分类  

            if(!empty($data)) {
                $se_array = array();
                foreach ($data['warnings'] as $key => $value) {
                    array_push($se_array,$value['leak_name']);
                    $chart_severity_metrics = array_count_values($se_array);
                }
            }

            //数据整理
            $up_data = array();
            foreach($chart_severity_metrics as $k => $v){
                foreach($data['warnings'] as $data_key => &$data_value){
                    if($k == $data_value['leak_name']){
                        $up_data[$k]['content'][] = $data_value;
                    }
                }
            }

            foreach($degree_clas as $k => $v){   //在线审计头部高中低忽略所有的数据
                if($k == '1'){
                    $degree_class['高'] = $v;
                }else if($k == '2'){
                    $degree_class['中'] = $v;
                }else if($k == '3'){
                    $degree_class['低'] = $v;
                }else if($k == '4'){
                    $degree_class['忽略'] = $v;
                }
            }

            $degree_class['所有'] = array_sum($degree_class);
            if(!$degree_class['高']){
                $degree_class['高'] = '0';
            }
            if(!$degree_class['中']){
                $degree_class['中'] = '0';
            }
            if(!$degree_class['低']){
                $degree_class['低'] = '0';
            }
            if(!$degree_class['忽略']){
                $degree_class['忽略'] = '0';
            }

            $this->assign('data_type',$level);
            $this->assign('up_data',$up_data);
            $this->assign('info_id',$info_id);
            $this->assign('degree_class',$degree_class);
            $this->display("online");
        }else{
            $this->redirect('Home/Index/index');//如果未登录。跳转到登录页
        }
    }


    //代码分析 --- 在线审计右侧读取文件
    public function online_right(){
        //筛选指定数据
        $data_type = !empty($_GET['data_type']) ? $_GET['data_type'] : 5;

        //获取审计数据
        $fu_key = !empty($_GET['fu_key']) ? $_GET['fu_key'] : ''; //获取数据父级
        $key_id = $_GET['key_id'] != null ? $_GET['key_id'] : ''; //获取父级子级

        $login = D('Analysis');
            if($_GET['info_id']){
                $info_id = $_GET['info_id'];
            }else{
                $info_id = $login->new_detection();//获取最近检测的upload_id
            }
            $file_path = $login->GetTaskname($info_id);
            $summary_id = $login->getSummaryId($info_id);

        if($fu_key && $key_id != null){
            $data['warnings'] = $login->branch_detail_class($summary_id,'',$data_type);

            $chart_vulntype_metrics = array(); //风险分类
            /*风险代码视图种类*/
            if(!empty($data)) {
                $fe_array = array();
                $vu_array = array();
                $se_array = array();
                foreach ($data['warnings'] as $key => $value) {
                    array_push($vu_array,$value['leak_name']);
                    $chart_vulntype_metrics = array_count_values($vu_array);
                }
            }

            //数据整理
            $up_data = array();
            foreach($chart_vulntype_metrics as $k => $v){
                foreach($data['warnings'] as $data_key => &$data_value){
                    if($k == $data_value['leak_name']){
                        $up_data[$k]['content'][] = $data_value;
                    }
                }
            }

            $audit = array(
                'track' => array( //跟踪路径
                    'file' => $up_data[$fu_key]['content'][$key_id]['leak_file_pos'],
                    'line' => $up_data[$fu_key]['content'][$key_id]['leak_line_num'],
                    'code' => $up_data[$fu_key]['content'][$key_id]['code_part'],
                ),
                'warning_ms' =>  $up_data[$fu_key]['content'][$key_id]['leak_defect_des'], //缺陷描述
                'message' =>  $up_data[$fu_key]['content'][$key_id]['leak_modify_sug'], //修复建议
                'link' =>  $up_data[$fu_key]['content'][$key_id]['link'], //参考信息
                'severity' =>  $up_data[$fu_key]['content'][$key_id]['leak_grade'], //警告等级
                'describe' =>  !empty($up_data[$fu_key]['content'][$key_id]['describe']) ? $up_data[$fu_key][$key_id]['describe'] : '', //警告等级
            );

                $file_rout = $file_path.'/'.$up_data[$fu_key]['content'][$key_id]['leak_file_pos'];
                $content = file_get_contents($file_rout); 

                $content = is_file($file_rout) ? file_get_contents($file_rout) : '';

                $content_array = $content ? explode(PHP_EOL,htmlspecialchars($content)) : ''; //\t数据分割整理数据
                $data_json = json_encode($audit['track']); //获取表格json数据


        }

        //缺陷审计form提交数据处理
        $file = !empty($_POST['file']) ? $_POST['file'] : ''; //form提交file文件名称
        $line = !empty($_POST['line']) ? $_POST['line'] : ''; //form提交line的行号数据
        $warning_type = !empty($_POST['warning_type']) ? $_POST['warning_type'] : ''; //form提交的那个数据类型
        $severity = !empty($_POST['grade']) ? $_POST['grade'] : '';//获取审计类型
        $describe = !empty($_POST['describe']) ? $_POST['describe'] : '';//获取审计的描述消息
        $type = 0;//是否审计 1：位审计
        if($file && $line && $warning_type){
        //根据文件名称和错误行号来更新json数据
            foreach($data['warnings'] as $da_key => &$da_value){
                if($da_value['file'] == $file && $da_value['line'] == $line && $da_value['warning_type'] == $warning_type){
                    $da_value['severity'] = $severity;
                    $da_value['describe'] = $describe;
                    $da_value['type'] = 1;
                }
            }

            $new_json = json_encode($data); //获取新的json数据
            //写入文件
            exec("sudo chmod -R 777 /var/raptor/scan_results/");
            $myfile = fopen($_SESSION['current_scan_report'], "w") or die("没有此文件!");
            $sec = fwrite($myfile, $new_json);
            if($sec){
                if(!empty($_GET['data_type'])){
                    $data_type = "?data_type={$_GET['data_type']}";
                }else{
                    $data_type = '';
                }
                echo '<script>top.location="online.php'.$data_type.'"</script>';
            }
            fclose($myfile);
        }

        $this->assign('data_json',$data_json);
        $this->assign('content_array',$content_array);
        $this->assign('audit',$audit);
        $this->display("online_right");
    }

    //获取分览表格
    public function owerdata(){
        $codetype = $_GET['codetype']; //文件类型 java php ...
        $level = !empty($_GET['level']) ? trim($_GET['level']) : 'all'; //等级 高 中 低
        $risk = !empty($_GET['risk']) ? trim($_GET['risk']) : '';
        $info_id = $_GET['info_id']; //查看文件id
        if($level != 'all'){
            if($level == '高'){
                $level = 1;
            }elseif($level == '中'){
                $level = 2;
            }elseif($level == '低'){
                $level = 3;
            }elseif($level == '忽略'){
                $level = 4;
            }
            $leak_grade = " and c.leak_grade = $level";
        }
        if($risk){
            $leak_name = " and c.leak_name = '{$risk}'";
        }
        $Model = M('upload_info');
        $res_data = $Model->table('__UPLOAD_INFO__ AS a')
            ->join('__SCAN_SUMMARY__ AS b ON a.id = b.upinfo_id')
            ->join('__SCAN_DATA__ AS c ON b.id = c.summary_id')
            ->where("a.id = '%s' and c.file_type_name = '%s' $leak_grade $leak_name",$info_id,$codetype)
            ->field('c.leak_grade,c.leak_name,c.leak_file_pos,c.leak_line_num,c.code_part')
            ->select();
        //数据整理
        foreach($res_data as $data_key => &$data_value){
            $data_value['leak_file_pos'] = $data_value['leak_file_pos'].'#L'.$data_value['leak_line_num'];
            if($data_value['leak_grade'] == 1){
                $data_value['leak_grade'] = '高';
            }elseif($data_value['leak_grade'] == 2){
                $data_value['leak_grade'] = '中';
            }elseif($data_value['leak_grade'] == 3){
                $data_value['leak_grade'] = '低';
            }elseif($data_value['leak_grade'] == 4){
                $data_value['leak_grade'] = '忽略';
            }
        }
        $this->ajaxReturn($res_data,'json');
    }

}